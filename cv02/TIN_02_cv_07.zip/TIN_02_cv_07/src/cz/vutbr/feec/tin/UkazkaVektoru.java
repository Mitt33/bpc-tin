package cz.vutbr.feec.tin;

import java.util.Vector;

public class UkazkaVektoru {
	public static void main(String[] args) {
		Vector<Auto> mujVektor = new Vector<>();
		mujVektor.add(new Auto());
	}
}
