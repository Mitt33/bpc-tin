package cz.vutbr.feec.tin.adresar;

public class Adresar {
	private Adresar levy;
	private Adresar pravy;
	// SHIFT + ALT + S
	public Adresar getLevy() {
		return levy;
	}
	public void setLevy(Adresar levy) {
		this.levy = levy;
	}
	public Adresar getPravy() {
		return pravy;
	}
	public void setPravy(Adresar pravy) {
		this.pravy = pravy;
	}
}
